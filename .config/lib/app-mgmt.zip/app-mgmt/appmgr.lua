-- Execution Tools Library
-- Created by Alexankitty
-- Features functions for executing commands and managing running binaries.
-- Supports uwsm via runapp
-- Set dsp: true in any exec/runapp function to run in dispatcher mode (Required for bind and dispatch functions)

-- Returns the binary name without args

local appmgr = {dsp = false}

function appmgr:new(o, dsp)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    o.dsp = dsp
    o.Get_Binary = function(cmd)
        return string.match(cmd, "^(('.*')|([^\\s]+))")
    end
    o.Is_Running = function(cmd)
        local binary = o.Get_Binary(cmd)
        local i, t, popen = 0, {}, io.popen
        local pfile = popen("pidof " .. binary)
        for pid in pfile:lines() do
            t[i] = pid
            i = i + 1
        end
        pfile:close()
        return i > 0
    end
    o.Kill = function(cmd)
        hl.exec_cmd("killall " .. o.Get_Binary(cmd)) -- this should never return a dispatcher
    end
    o.Exec = function(cmd)
        if o.dsp then
            return hl.dsp.exec_cmd(cmd)
        else
            return hl.exec_cmd(cmd)
        end
    end
    o.Runapp = function(cmd)
        return o.Exec("runapp " .. cmd)
    end
    o.Exec_Delayed = function(cmd)
        return o.Exec("sleep 1 && " .. cmd)
    end
    o.Runapp_Delayed = function(cmd)
        return o.Exec("sleep 1 && runapp " .. cmd)
    end
    o.Exec_Replace = function(cmd, true_name)
        if true_name == nil then
            true_name = cmd
        end
        if o.Is_Running(true_name) then
            o.Kill(true_name)
        end
        return o.Exec(cmd)
    end
    o.Runapp_Replace = function(cmd, true_name)
        if true_name == nil then
            true_name = cmd
        end
        if o.Is_Running(true_name) then
            o.Kill(true_name)
        end
        return o.Runapp(cmd)
    end
    o.Exec_Once = function(cmd, true_name)
        if true_name == nil then
            true_name = cmd
        end
        if not o.Is_Running(true_name) then
            return o.Exec(cmd)
        end
    end
    o.Runapp_Once = function(cmd, true_name)
        if true_name == nil then
            true_name = cmd
        end
        if not o.Is_Running(true_name) then
            return o.Runapp(cmd)
        end
    end
    return o
end

return appmgr
