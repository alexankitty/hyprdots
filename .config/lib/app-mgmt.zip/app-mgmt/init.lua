local info = debug.getinfo(1, 'S')
local this_dir = string.match(info.source, '^@(.*)/')

package.path = this_dir .. "/?.lua;" .. package.path

local Appmgr = __require("appmgr")
App = Appmgr:new(nil)
App.Dsp = Appmgr:new(nil, true)
